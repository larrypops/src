'use client';

import { useMemo, useState, useEffect } from 'react';
import { useData } from '@/hooks/use-data';
import { KpiCard } from '@/components/kpi-card';
import { ResultsAnalysis } from '@/components/results-analysis';
import { Users, Percent, CheckSquare, Vote, FileX, FileQuestion } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { DetailedResultsTable } from '@/components/detailed-results-table';
import type { ElectionResult } from '@/lib/types';


export default function DashboardPage() {
  const { results, elections, loading, candidates, stations } = useData();
  const [selectedElectionId, setSelectedElectionId] = useState<string>('all');
  
  useEffect(() => {
    if (elections.length > 0 && selectedElectionId === 'all') {
       if (elections.length === 1) {
         setSelectedElectionId(elections[0].id);
       }
    } else if (elections.length > 0 && !elections.find(e => e.id === selectedElectionId)) {
        setSelectedElectionId('all');
    }
  }, [elections, selectedElectionId]);

  const { 
    totalRegistered, 
    totalTurnout, 
    turnoutPercentage, 
    totalSubmissions, 
    candidateTotals,
    totalInvalidBallots,
    totalBlankBallots,
    totalValidVotes,
    filteredResultsForTable,
    candidatesForTable,
  } = useMemo(() => {
    const filteredResults = selectedElectionId === 'all'
      ? results
      : results.filter(r => r.electionId === selectedElectionId);

    if (loading) {
        return {
            totalRegistered: 0, totalTurnout: 0, turnoutPercentage: '0.00', totalSubmissions: 0,
            candidateTotals: [], totalInvalidBallots: 0, totalBlankBallots: 0,
            totalValidVotes: 0, filteredResultsForTable: [], candidatesForTable: []
        };
    }

    // Use a map to aggregate data per station for the current election
    const stationDataMap = new Map<string, { registered: number, turnout: number }>();
    
    // We get the full list of stations for the selected election
    const resultsForSelectedElection = selectedElectionId === 'all' ? results : results.filter(r => r.electionId === selectedElectionId);

    resultsForSelectedElection.forEach(r => {
        stationDataMap.set(r.pollingStation, {
            registered: r.registeredVoters,
            turnout: r.turnout
        });
    });

    const totalRegisteredAgg = Array.from(stationDataMap.values()).reduce((sum, r) => sum + r.registered, 0);
    const totalTurnoutAgg = Array.from(stationDataMap.values()).reduce((sum, r) => sum + r.turnout, 0);
    const turnoutPercentageCalc = totalRegisteredAgg > 0 ? ((totalTurnoutAgg / totalRegisteredAgg) * 100).toFixed(2) : '0.00';
    
    const totalSubmissions = stationDataMap.size;
    
    const totalInvalidBallotsAgg = filteredResults.reduce((sum, r) => sum + r.invalidBallots, 0);
    const totalBlankBallotsAgg = filteredResults.reduce((sum, r) => sum + r.blankBallots, 0);

    const candidateMap = new Map<string, number>();
    filteredResults.forEach(result => {
      result.candidateResults.forEach(candidate => {
        candidateMap.set(candidate.name, (candidateMap.get(candidate.name) || 0) + candidate.votes);
      });
    });
    
    const relevantCandidates = selectedElectionId === 'all'
      ? []
      : candidates.filter(c => c.electionId === selectedElectionId);

    const candidateTotals = relevantCandidates
      .map(c => ({
        name: c.name,
        party: c.party,
        photoUrl: c.photoUrl,
        votes: candidateMap.get(c.name) || 0,
      }))
      .sort((a, b) => b.votes - a.votes);

    const totalValidVotes = candidateTotals.reduce((sum, c) => sum + c.votes, 0);

    return {
      totalRegistered: totalRegisteredAgg,
      totalTurnout: totalTurnoutAgg,
      turnoutPercentage: turnoutPercentageCalc,
      totalSubmissions,
      candidateTotals,
      totalInvalidBallots: totalInvalidBallotsAgg,
      totalBlankBallots: totalBlankBallotsAgg,
      totalValidVotes,
      filteredResultsForTable: filteredResults,
      candidatesForTable: relevantCandidates,
    };
  }, [results, selectedElectionId, candidates, elections, loading]);


  const handleElectionChange = (electionId: string) => {
    setSelectedElectionId(electionId);
  };
  
  const getElectionName = (electionId: string) => {
    if (electionId === 'all') return "Toutes les élections";
    return elections.find(e => e.id === electionId)?.name || "Élection inconnue";
  }

  if (loading) {
    return (
       <div className="space-y-8">
        <div className="flex items-center justify-between">
          <Skeleton className="h-9 w-64" />
          <Skeleton className="h-10 w-72" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-[500px]" />
        <Skeleton className="h-[500px]" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline">Tableau de bord</h1>
          <p className="text-muted-foreground">Affichage des résultats pour : <span className="font-semibold text-primary">{getElectionName(selectedElectionId)}</span></p>
        </div>
        <div className="w-full sm:w-auto">
          <Select onValueChange={handleElectionChange} value={selectedElectionId}>
            <SelectTrigger className="w-full sm:w-72">
              <SelectValue placeholder="Filtrer par élection" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les élections</SelectItem>
              {elections.map((election) => (
                <SelectItem key={election.id} value={election.id}>
                  {election.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <KpiCard
          title="Électeurs inscrits"
          value={totalRegistered.toLocaleString()}
          description="Total des électeurs pour la sélection"
          icon={<Users className="h-4 w-4 text-muted-foreground" />}
        />
        <KpiCard
          title="Participation"
          value={totalTurnout.toLocaleString()}
          description="Nombre total de votants"
          icon={<Vote className="h-4 w-4 text-muted-foreground" />}
        />
        <KpiCard
          title="Taux de participation"
          value={`${turnoutPercentage}%`}
          description="Pourcentage d'électeurs ayant voté"
          icon={<Percent className="h-4 w-4 text-muted-foreground" />}
        />
        <KpiCard
          title="Bureaux rapportés"
          value={`${totalSubmissions.toLocaleString()} / ${stations.length.toLocaleString()}`}
          description="Bureaux ayant soumis leurs résultats"
          icon={<CheckSquare className="h-4 w-4 text-muted-foreground" />}
        />
         <KpiCard
          title="Bulletins nuls"
          value={totalInvalidBallots.toLocaleString()}
          description="Total des bulletins déclarés nuls"
          icon={<FileX className="h-4 w-4 text-muted-foreground" />}
        />
        <KpiCard
          title="Bulletins blancs"
          value={totalBlankBallots.toLocaleString()}
          description="Total des bulletins blancs"
          icon={<FileQuestion className="h-4 w-4 text-muted-foreground" />}
        />
      </div>

        {selectedElectionId !== 'all' ? (
          <ResultsAnalysis candidateData={candidateTotals} totalValidVotes={totalValidVotes} />
        ) : (
          <Card className="flex items-center justify-center min-h-[400px] shadow-sm">
              <p className="text-muted-foreground text-center">Veuillez sélectionner une élection pour voir l'analyse des candidats.</p>
          </Card>
        )}

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Résultats Détaillés par Bureau de Vote</CardTitle>
          <CardDescription>
            Analyse approfondie pour l'élection sélectionnée. Cliquez sur les en-têtes de colonne pour trier.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredResultsForTable.length > 0 && selectedElectionId !== 'all' ? (
            <DetailedResultsTable
              results={filteredResultsForTable}
              stations={stations}
              candidates={candidatesForTable}
            />
          ) : (
            <div className="text-center h-48 flex items-center justify-center">
              <p className="text-muted-foreground">
                {selectedElectionId === 'all' 
                  ? "Veuillez sélectionner une élection pour voir les résultats détaillés."
                  : "Aucune donnée de résultat pour la sélection actuelle."}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
