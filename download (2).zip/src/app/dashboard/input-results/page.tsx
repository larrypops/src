'use client';

import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useData } from '@/hooks/use-data';
import { useToast } from '@/hooks/use-toast';
import { LoaderCircle, Upload } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useEffect, useState, useMemo, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useAuth } from '@/hooks/use-auth';


const candidateSchema = z.object({
  name: z.string().min(1, 'Le nom du candidat est requis'),
  votes: z.coerce.number().min(0, 'Les votes ne peuvent pas être négatifs'),
});

const resultsSchema = z
  .object({
    electionId: z.string().min(1, 'Veuillez sélectionner une élection.'),
    pollingStation: z.string().min(1, 'Veuillez sélectionner un bureau de vote.'),
    registeredVoters: z.coerce.number().int().min(1, 'Le nombre d\'électeurs inscrits doit être d\'au moins 1.'),
    turnout: z.coerce.number().int().min(0, 'La participation ne peut pas être négative.'),
    candidateResults: z.array(candidateSchema).min(1, 'Au moins un candidat est requis.'),
    invalidBallots: z.coerce.number().int().min(0, 'Les bulletins nuls ne peuvent pas être négatifs.'),
    blankBallots: z.coerce.number().int().min(0, 'Les bulletins blancs ne peuvent pas être négatifs.'),
  })
  .refine((data) => data.turnout <= data.registeredVoters, {
    message: 'La participation ne peut pas dépasser le nombre d\'électeurs inscrits.',
    path: ['turnout'],
  })
  .refine(
    (data) => {
      const totalVotesCast =
        data.candidateResults.reduce((sum, candidate) => sum + candidate.votes, 0) +
        data.invalidBallots +
        data.blankBallots;
      return totalVotesCast === data.turnout;
    },
    {
      message: 'La somme de tous les votes (candidats, nuls, blancs) doit être égale à la participation.',
      path: ['blankBallots'], // Assign error to the last field in the group
    }
  );

type ResultsFormValues = z.infer<typeof resultsSchema>;

export default function InputResultsPage() {
  const { addResult, stations, candidates, elections } = useData();
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedElectionId, setSelectedElectionId] = useState<string>('');
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const userStation = useMemo(() => {
    if (user?.role !== 'Super Admin' && user?.pollingStationId) {
      return stations.find(s => s.id === user.pollingStationId);
    }
    return null;
  }, [user, stations]);

  const form = useForm<ResultsFormValues>({
    resolver: zodResolver(resultsSchema),
    defaultValues: {
      electionId: '',
      pollingStation: '',
      registeredVoters: 0,
      turnout: 0,
      candidateResults: [],
      invalidBallots: 0,
      blankBallots: 0,
    },
  });

  useEffect(() => {
    if (userStation) {
      form.setValue('pollingStation', userStation.name);
    }
  }, [userStation, form]);

  const { fields, replace } = useFieldArray({
    control: form.control,
    name: 'candidateResults',
  });
  
  const candidatesForSelectedElection = useMemo(() => {
    return candidates.filter(c => c.electionId === selectedElectionId);
  }, [candidates, selectedElectionId]);

  useEffect(() => {
    if (selectedElectionId) {
      const candidateFields = candidatesForSelectedElection.map(c => ({ name: c.name, votes: 0 }));
      replace(candidateFields);
    } else {
      replace([]);
    }
  }, [selectedElectionId, candidatesForSelectedElection, replace]);


  const onSubmit = (data: ResultsFormValues) => {
    try {
      addResult(data);
      toast({
        title: 'Succès !',
        description: 'Les résultats des élections ont été soumis.',
      });
      form.reset();
      if (userStation) {
        form.setValue('pollingStation', userStation.name);
      }
      setSelectedElectionId('');
      replace([]);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'La soumission a échoué',
        description: error instanceof Error ? error.message : 'Une erreur inattendue est survenue.',
      });
    }
  };

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
        const text = e.target?.result;
        if (typeof text !== 'string') {
            toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de lire le fichier.' });
            setIsImporting(false);
            return;
        }

        const lines = text.split(/\r\n|\n/).filter(line => line.trim() !== '');
        const header = lines.shift()?.split(',').map(h => h.trim().toLowerCase()) || [];
        
        const requiredHeaders = ['electionid', 'pollingstation', 'registeredvoters', 'turnout', 'invalidballots', 'blankballots'];
        const hasRequiredHeaders = requiredHeaders.every(h => header.includes(h));

        if (!hasRequiredHeaders) {
            toast({ variant: 'destructive', title: 'Format de fichier invalide', description: "L'en-tête du CSV est incorrect." });
            setIsImporting(false);
            return;
        }

        let successCount = 0;
        let errorCount = 0;

        for (const line of lines) {
            const values = line.split(',').map(field => field.trim());
            const rowData: { [key: string]: string } = header.reduce((obj, h, i) => {
                obj[h] = values[i];
                return obj;
            }, {});

            const candidateResults: { name: string, votes: number }[] = [];
            for (let i = 0; i < (header.length - requiredHeaders.length) / 2; i++) {
                const nameKey = `candidate_${i + 1}_name`;
                const votesKey = `candidate_${i + 1}_votes`;
                if (rowData[nameKey] && rowData[votesKey]) {
                    candidateResults.push({
                        name: rowData[nameKey],
                        votes: parseInt(rowData[votesKey], 10)
                    });
                }
            }
            
            const parseResult = resultsSchema.safeParse({
                electionId: rowData.electionid,
                pollingStation: rowData.pollingstation,
                registeredVoters: parseInt(rowData.registeredvoters, 10),
                turnout: parseInt(rowData.turnout, 10),
                invalidBallots: parseInt(rowData.invalidballots, 10),
                blankBallots: parseInt(rowData.blankballots, 10),
                candidateResults: candidateResults,
            });

            if (parseResult.success) {
                try {
                    addResult(parseResult.data);
                    successCount++;
                } catch (e) {
                    errorCount++;
                }
            } else {
                console.error("CSV line validation error:", parseResult.error);
                errorCount++;
            }
        }
        
        toast({
            title: 'Importation terminée',
            description: `${successCount} résultats ajoutés, ${errorCount} erreurs.`,
        });

        setIsImporting(false);
        setIsDialogOpen(false);
    };

    reader.onerror = () => {
       toast({ variant: 'destructive', title: 'Erreur de lecture', description: 'Une erreur s\'est produite lors de la lecture du fichier.' });
       setIsImporting(false);
    };

    reader.readAsText(file);
    
    if(fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };


  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold font-headline">Saisir les résultats</h1>
        {user?.role === 'Super Admin' && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="mr-2" />
                Importer un CSV
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Importer les résultats</DialogTitle>
                <DialogDescription>
                  <p>Sélectionnez un fichier CSV. Le fichier doit avoir les colonnes : </p>
                  <code className="font-mono bg-muted p-1 rounded-sm text-sm break-all">
                    electionId,pollingStation,registeredVoters,turnout,invalidBallots,blankBallots,candidate_1_name,candidate_1_votes,...
                  </code>
                </DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <Input 
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  ref={fileInputRef}
                  onChange={handleFileImport}
                  disabled={isImporting}
                />
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline" disabled={isImporting}>Annuler</Button>
                </DialogClose>
                {isImporting && <LoaderCircle className="h-4 w-4 animate-spin" />}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Nouvelle entrée de résultat</CardTitle>
          <CardDescription>Remplissez le formulaire ci-dessous pour soumettre les résultats d'un bureau de vote.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                 <FormField
                  control={form.control}
                  name="electionId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Élection</FormLabel>
                       <Select 
                          onValueChange={(value) => {
                            field.onChange(value);
                            setSelectedElectionId(value);
                          }} 
                          defaultValue={field.value}
                        >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez une élection" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {elections.map(election => (
                            <SelectItem key={election.id} value={election.id}>{election.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pollingStation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bureau de vote</FormLabel>
                       <Select onValueChange={field.onChange} value={field.value} disabled={!!userStation}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez un bureau de vote" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {stations.map(station => (
                            <SelectItem key={station.id} value={station.name}>{station.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="registeredVoters"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Électeurs inscrits</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="ex: 5000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="turnout"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Participation électorale</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="ex: 3500" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-4">Votes par candidat</h3>
                 {fields.length > 0 ? (
                  <div className="space-y-4">
                    {fields.map((field, index) => (
                      <div key={field.id} className="grid grid-cols-[1fr_auto] items-end gap-4">
                        <FormField
                          control={form.control}
                          name={`candidateResults.${index}.name`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="sr-only">Nom du candidat</FormLabel>
                              <FormControl>
                                <Input {...field} readOnly className="font-medium bg-muted" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`candidateResults.${index}.votes`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="sr-only">Votes</FormLabel>
                              <FormControl>
                                <Input type="number" placeholder="Votes" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                   <p className="text-sm text-muted-foreground">
                    Veuillez d'abord sélectionner une élection pour voir les candidats.
                  </p>
                )}
              </div>

              <Separator />

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="invalidBallots"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bulletins nuls</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="ex: 40" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="blankBallots"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bulletins blancs</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="ex: 10" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={!selectedElectionId || form.formState.isSubmitting}>
                  {form.formState.isSubmitting && <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />}
                  Soumettre les résultats
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
