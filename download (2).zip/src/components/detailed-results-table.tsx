'use client';

import { useMemo, useState } from 'react';
import type { ElectionResult, PollingStation, Candidate } from '@/lib/types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { ArrowUpDown } from 'lucide-react';
import { Badge } from './ui/badge';

type SortableKeys = 'pollingStation' | 'turnoutRate' | 'turnout' | 'registeredVoters' | string; // string for candidate names

interface DetailedResultsTableProps {
  results: ElectionResult[];
  stations: PollingStation[];
  candidates: Candidate[];
}

export function DetailedResultsTable({ results, stations, candidates }: DetailedResultsTableProps) {
  const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'ascending' | 'descending' }>({
    key: 'turnoutRate',
    direction: 'descending',
  });

  const stationMap = useMemo(() => {
    const map = new Map<string, Omit<PollingStation, 'id'>>();
    stations.forEach(s => map.set(s.name, { name: s.name, city: s.city, district: s.district }));
    return map;
  }, [stations]);

  const enrichedResults = useMemo(() => {
    return results.map(result => {
      const stationInfo = stationMap.get(result.pollingStation) ?? { city: 'N/A', district: 'N/A' };
      const turnoutRate = result.registeredVoters > 0 ? (result.turnout / result.registeredVoters) * 100 : 0;
      const validVotes = result.candidateResults.reduce((sum, c) => sum + c.votes, 0);
      const nullAndBlankPercentage = result.turnout > 0 ? ((result.invalidBallots + result.blankBallots) / result.turnout) * 100 : 0;
      
      const candidateScores: Record<string, { votes: number, percentage: number }> = {};
      candidates.forEach(c => {
        const candidateResult = result.candidateResults.find(cr => cr.name === c.name);
        const votes = candidateResult ? candidateResult.votes : 0;
        candidateScores[c.name] = {
          votes: votes,
          percentage: validVotes > 0 ? (votes / validVotes) * 100 : 0,
        };
      });

      return {
        ...result,
        ...stationInfo,
        turnoutRate,
        validVotes,
        nullAndBlankPercentage,
        ...candidateScores,
      };
    });
  }, [results, stationMap, candidates]);

  const sortedResults = useMemo(() => {
    const sortableItems = [...enrichedResults];
    sortableItems.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      if (candidates.some(c => c.name === sortConfig.key)) {
         aValue = a[sortConfig.key]?.votes ?? 0;
         bValue = b[sortConfig.key]?.votes ?? 0;
      } else {
         aValue = a[sortConfig.key as keyof typeof a];
         bValue = b[sortConfig.key as keyof typeof b];
      }

      if (aValue < bValue) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });
    return sortableItems;
  }, [enrichedResults, sortConfig, candidates]);

  const requestSort = (key: SortableKeys) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIndicator = (key: SortableKeys) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'descending' ? '▼' : '▲';
  };

  return (
    <div className="w-full overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>
              <Button variant="ghost" onClick={() => requestSort('pollingStation')}>
                Bureau de Vote {getSortIndicator('pollingStation')}
              </Button>
            </TableHead>
            <TableHead>Localisation</TableHead>
            <TableHead>
              <Button variant="ghost" onClick={() => requestSort('registeredVoters')}>
                Inscrits {getSortIndicator('registeredVoters')}
              </Button>
            </TableHead>
            <TableHead>
              <Button variant="ghost" onClick={() => requestSort('turnout')}>
                Exprimés {getSortIndicator('turnout')}
              </Button>
            </TableHead>
            <TableHead>
              <Button variant="ghost" onClick={() => requestSort('turnoutRate')}>
                Taux Part. {getSortIndicator('turnoutRate')}
              </Button>
            </TableHead>
            <TableHead>Nuls/Blancs</TableHead>
            {candidates.map(candidate => (
              <TableHead key={candidate.id}>
                <Button variant="ghost" onClick={() => requestSort(candidate.name)}>
                  {candidate.name} {getSortIndicator(candidate.name)}
                </Button>
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedResults.map(item => (
            <TableRow key={item.id}>
              <TableCell className="font-medium">{item.pollingStation}</TableCell>
              <TableCell className="text-sm text-muted-foreground">{item.city}, {item.district}</TableCell>
              <TableCell className="text-right">{item.registeredVoters.toLocaleString()}</TableCell>
              <TableCell className="text-right">{item.turnout.toLocaleString()}</TableCell>
              <TableCell className="text-right">
                <Badge variant={item.turnoutRate < 60 ? "destructive" : item.turnoutRate < 70 ? "secondary" : "default"} className="font-bold">
                  {item.turnoutRate.toFixed(1)}%
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <div>{(item.invalidBallots + item.blankBallots).toLocaleString()}</div>
                <div className="text-xs text-muted-foreground">({item.nullAndBlankPercentage.toFixed(1)}%)</div>
              </TableCell>
              {candidates.map(candidate => {
                const score = item[candidate.name] as { votes: number; percentage: number };
                return (
                  <TableCell key={candidate.id} className="text-right">
                    <div>{score.votes.toLocaleString()}</div>
                    <div className="text-xs text-muted-foreground">({score.percentage.toFixed(1)}%)</div>
                  </TableCell>
                )
              })}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
