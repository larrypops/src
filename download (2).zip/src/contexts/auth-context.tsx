'use client';

import type { ReactNode } from 'react';
import { createContext, useState, useEffect, useCallback, useContext } from 'react';
import { useRouter } from 'next/navigation';
import type { User } from '@/lib/types';
import { DataContext } from '@/contexts/data-context';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const dataContext = useContext(DataContext);


  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('elections-camer-user');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error('Failed to parse user from localStorage', error);
      localStorage.removeItem('elections-camer-user');
    } finally {
      setLoading(false);
    }
  }, []);

  const login = useCallback((email: string, password: string) => {
    if (!dataContext) {
      throw new Error('DataContext is not available');
    }
    const { users } = dataContext;
    
    const userToLogin = users.find(u => u.email === email && u.password === password);

    if (userToLogin) {
      const loggedInUser: User = {
        ...userToLogin,
        avatar: `https://i.pravatar.cc/150?u=${userToLogin.id}`,
      };
      localStorage.setItem('elections-camer-user', JSON.stringify(loggedInUser));
      setUser(loggedInUser);
      router.push('/dashboard');
    } else {
      throw new Error('Identifiants invalides.');
    }
  }, [router, dataContext]);

  const logout = useCallback(() => {
    localStorage.removeItem('elections-camer-user');
    setUser(null);
    router.push('/login');
  }, [router]);

  const value = { user, loading, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
