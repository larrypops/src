'use client';

import type { ReactNode } from 'react';
import { createContext, useState, useEffect, useCallback, useContext } from 'react';
import type { ElectionResult, PollingStation, Candidate, Election, User } from '@/lib/types';
import { AuthContext } from '@/contexts/auth-context';

interface DataContextType {
  results: ElectionResult[];
  stations: PollingStation[];
  candidates: Candidate[];
  elections: Election[];
  users: User[];
  addResult: (newResult: Omit<ElectionResult, 'id' | 'timestamp' | 'submittedBy'>) => void;
  addStation: (newStation: Omit<PollingStation, 'id'>) => void;
  addCandidate: (newCandidate: Omit<Candidate, 'id'>) => void;
  addElection: (newElection: Omit<Election, 'id'>) => void;
  addUser: (newUser: Omit<User, 'id' | 'avatar'>) => void;
  loading: boolean;
}

export const DataContext = createContext<DataContextType | undefined>(undefined);

const initialElections: Election[] = [
    { id: 'elec-1', name: 'Présidentielle 2025', date: '2025-10-12T00:00:00.000Z' },
];

const initialStations: PollingStation[] = [
    { id: 'ps-1', name: 'Bureau de vote central de Yaoundé', city: 'Yaoundé', district: 'Yaoundé I' },
    { id: 'ps-2', name: 'Bureau portuaire de Douala', city: 'Douala', district: 'Douala IV' },
    { id: 'ps-3', name: 'Bureau des hauts plateaux de Bamenda', city: 'Bamenda', district: 'Bamenda II' },
    { id: 'ps-4', name: 'Poste nord de Garoua', city: 'Garoua', district: 'Garoua III' },
];

const initialCandidates: Candidate[] = [
  { id: 'cand-1', electionId: 'elec-1', name: 'Candidat A', party: 'Parti Démocratique', photoUrl: 'https://picsum.photos/seed/1/200/200' },
  { id: 'cand-2', electionId: 'elec-1', name: 'Candidat B', party: 'Parti de l\'Union', photoUrl: 'https://picsum.photos/seed/2/200/200' },
  { id: 'cand-3', electionId: 'elec-1', name: 'Candidat C', party: 'Mouvement du Peuple', photoUrl: 'https://picsum.photos/seed/3/200/200' },
];

const initialResults: Omit<ElectionResult, 'id' | 'timestamp' | 'submittedBy'>[] = [
    {
        electionId: "elec-1",
        pollingStation: "Bureau de vote central de Yaoundé",
        registeredVoters: 5000,
        turnout: 3500,
        candidateResults: [
            { name: "Candidat A", votes: 1500 },
            { name: "Candidat B", votes: 1800 },
            { name: "Candidat C", votes: 150 },
        ],
        invalidBallots: 40,
        blankBallots: 10,
    },
    {
        electionId: "elec-1",
        pollingStation: "Bureau portuaire de Douala",
        registeredVoters: 7200,
        turnout: 5400,
        candidateResults: [
            { name: "Candidat A", votes: 2200 },
            { name: "Candidat B", votes: 2900 },
            { name: "Candidat C", votes: 250 },
        ],
        invalidBallots: 30,
        blankBallots: 20,
    }
];

const initialUsers: User[] = [
    { id: 'user-1', name: 'Super Administrateur', email: 'superadmin@elections.com', role: 'Super Admin', password: 'password123', avatar: `https://i.pravatar.cc/150?u=user-1` },
    { id: 'user-5', name: 'Larry Effa', email: 'larryeffa17@gmail.com', role: 'Super Admin', password: 'password123', avatar: `https://i.pravatar.cc/150?u=user-5` },
    { id: 'user-6', name: 'Admin', email: 'admin@admin.com', role: 'Super Admin', password: 'Pops2356/', avatar: `https://i.pravatar.cc/150?u=user-6` },
    { id: 'user-2', name: 'Agent de Bureau Yaoundé', email: 'station@elections.com', role: 'Bureau de Vote', password: 'password123', avatar: `https://i.pravatar.cc/150?u=user-2`, pollingStationId: 'ps-1' },
    { id: 'user-3', name: 'Admin Douala', email: 'admin@elections.com', role: 'Admin', password: 'password123', avatar: `https://i.pravatar.cc/150?u=user-3`, pollingStationId: 'ps-2' },
    { id: 'user-4', name: 'Observateur National', email: 'viewer@elections.com', role: 'Observateur', password: 'password123', avatar: `https://i.pravatar.cc/150?u=user-4` },
];


export function DataProvider({ children }: { children: ReactNode }) {
  const [results, setResults] = useState<ElectionResult[]>([]);
  const [stations, setStations] = useState<PollingStation[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [elections, setElections] = useState<Election[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const authContext = useContext(AuthContext);

  useEffect(() => {
    setLoading(true);
    // Load users
    try {
      const storedUsers = localStorage.getItem('elections-camer-users');
      if (storedUsers) {
        setUsers(JSON.parse(storedUsers));
      } else {
        setUsers(initialUsers);
        localStorage.setItem('elections-camer-users', JSON.stringify(initialUsers));
      }
    } catch (error) {
      console.error('Failed to parse users from localStorage', error);
      localStorage.removeItem('elections-camer-users');
    }
    
    // Load elections
    try {
      const storedElections = localStorage.getItem('elections-camer-elections');
      if (storedElections) {
        setElections(JSON.parse(storedElections));
      } else {
        setElections(initialElections);
        localStorage.setItem('elections-camer-elections', JSON.stringify(initialElections));
      }
    } catch (error) {
      console.error('Failed to parse elections from localStorage', error);
      localStorage.removeItem('elections-camer-elections');
    }
    
    // Load stations
    try {
      const storedStations = localStorage.getItem('elections-camer-stations');
      if (storedStations) {
        setStations(JSON.parse(storedStations));
      } else {
        setStations(initialStations);
        localStorage.setItem('elections-camer-stations', JSON.stringify(initialStations));
      }
    } catch (error) {
      console.error('Failed to parse stations from localStorage', error);
      localStorage.removeItem('elections-camer-stations');
    }

    // Load candidates
    try {
      const storedCandidates = localStorage.getItem('elections-camer-candidates');
      if (storedCandidates) {
        setCandidates(JSON.parse(storedCandidates));
      } else {
        setCandidates(initialCandidates);
        localStorage.setItem('elections-camer-candidates', JSON.stringify(initialCandidates));
      }
    } catch (error) {
      console.error('Failed to parse candidates from localStorage', error);
      localStorage.removeItem('elections-camer-candidates');
    }

    // Load results
    try {
      const storedResults = localStorage.getItem('elections-camer-results');
      if (storedResults) {
        setResults(JSON.parse(storedResults));
      } else {
        const mockData = initialResults.map((r, i) => ({
            ...r,
            id: `result-${i+1}`,
            timestamp: new Date(Date.now() - (i * 1000 * 60 * 60 * 24)).toISOString(),
            submittedBy: 'Système'
        }));
        setResults(mockData);
        localStorage.setItem('elections-camer-results', JSON.stringify(mockData));
      }
    } catch (error) {
      console.error('Failed to parse results from localStorage', error);
      localStorage.removeItem('elections-camer-results');
    } finally {
      setLoading(false);
    }
  }, []);

  const addUser = useCallback((newUser: Omit<User, 'id' | 'avatar'>) => {
    setUsers(prevUsers => {
      const fullUser: User = {
        ...newUser,
        id: `user-${Date.now()}`,
        avatar: `https://i.pravatar.cc/150?u=user-${Date.now()}`,
      };
      const updatedUsers = [...prevUsers, fullUser];
      localStorage.setItem('elections-camer-users', JSON.stringify(updatedUsers));
      return updatedUsers;
    });
  }, []);

  const addResult = useCallback((newResult: Omit<ElectionResult, 'id' | 'timestamp' | 'submittedBy'>) => {
    if(!authContext?.user) return;
    
    setResults(prevResults => {
      const fullResult: ElectionResult = {
        ...newResult,
        id: `result-${Date.now()}`,
        timestamp: new Date().toISOString(),
        submittedBy: authContext.user.name,
      };
      const updatedResults = [...prevResults, fullResult];
      localStorage.setItem('elections-camer-results', JSON.stringify(updatedResults));
      return updatedResults;
    });
  }, [authContext?.user]);

  const addStation = useCallback((newStation: Omit<PollingStation, 'id'>) => {
    setStations(prevStations => {
      const fullStation: PollingStation = {
        ...newStation,
        id: `ps-${Date.now()}`,
      };
      const updatedStations = [...prevStations, fullStation];
      localStorage.setItem('elections-camer-stations', JSON.stringify(updatedStations));
      return updatedStations;
    });
  }, []);

  const addCandidate = useCallback((newCandidate: Omit<Candidate, 'id'>) => {
    setCandidates(prevCandidates => {
      const fullCandidate: Candidate = {
        ...newCandidate,
        id: `cand-${Date.now()}`,
      };
      const updatedCandidates = [...prevCandidates, fullCandidate];
      localStorage.setItem('elections-camer-candidates', JSON.stringify(updatedCandidates));
      return updatedCandidates;
    });
  }, []);
  
  const addElection = useCallback((newElection: Omit<Election, 'id'>) => {
    setElections(prevElections => {
      const fullElection: Election = {
        ...newElection,
        id: `elec-${Date.now()}`,
      };
      const updatedElections = [...prevElections, fullElection];
      localStorage.setItem('elections-camer-elections', JSON.stringify(updatedElections));
      return updatedElections;
    });
  }, []);

  const value = { results, stations, candidates, elections, users, addUser, addResult, addStation, addCandidate, addElection, loading };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}
